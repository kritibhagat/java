package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraft {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer_name == null) ? 0 : customer_name.hashCode());
		result = prime * result + ((in_favor_of == null) ? 0 : in_favor_of.hashCode());
		result = prime * result + ((phone_number == null) ? 0 : phone_number.hashCode());
		result = prime * result + ((dd_amount == null) ? 0 : dd_amount.hashCode());
		result = prime * result +((dd_description == null) ? 0 : dd_description.hashCode());
		//result = prime * result + ((regDate == null) ? 0 : regDate.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DemandDraft other = (DemandDraft)obj;
		if (customer_name == null) {
			if (other.customer_name != null)
				return false;
		} else if (!customer_name.equals(other.customer_name))
			return false;
		if (in_favor_of == null) {
			if (other.in_favor_of != null)
				return false;
		} else if (!in_favor_of.equals(other.in_favor_of))
			return false;
		if (phone_number == null) {
			if (other.phone_number != null)
				return false;
		} else if (!phone_number.equals(other.phone_number))
			return false;
		if (dd_amount == null) {
			if (other.dd_amount != null)
				return false;
		} else if (!dd_amount.equals(other.dd_amount))
			return false;
		if(dd_description == null) {
			if(other.dd_description != null)
		 return false;
			}
		else if (!dd_description.equals(other.dd_description))
			return false;
		
		
		return true;
	}



	private String in_favor_of;
	private String customer_name;
	private String phone_number;
	private String dd_amount;
	private String dd_description;
	
	
	

	public String getIn_favor_of() {
		return in_favor_of;
	}

	public void setIn_favor_of(String in_favor_of) {
		this.in_favor_of = in_favor_of;
	}



	public String getCustomer_name() {
		return customer_name;
	}



	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}



	public String getPhone_number() {
		return phone_number;
	}



	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}



	public String getDd_amount() {
		return dd_amount;
	}



	public void setDd_amount(String dd_amount) {
		this.dd_amount = dd_amount;
	}
	public String getDd_description() {
		return dd_description;
	}



	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}



	

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Name of the bank : XYZ \n");
		sb.append("Name of the customer : "+ customer_name +"\n");
		sb.append("In favor of" +in_favor_of +"\n");
		sb.append("phone number : " +phone_number +"\n");
		sb.append("DD Description: "+ dd_description +"\n");
		sb.append("DD Amount: "+ dd_amount +"\n");
	
		return sb.toString();
	}
	
}
