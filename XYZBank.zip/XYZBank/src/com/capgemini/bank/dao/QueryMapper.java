package com.capgemini.bank.dao;

public interface QueryMapper {

	//public static final String RETRIVE_ALL_QUERY="SELECT patient_name,phone,age,description FROM Patient";
	public static final String VIEW_CUSTOMER_DETAILS_QUERY="SELECT customer_name,dd_amount,dd_commission,dd_description FROM demand_draft WHERE transactionId=?";
	public static final String INSERT_QUERY="INSERT INTO demand_draft VALUES(transactionId_sequence.NEXTVAL,?,?,?,(select SYSDATE from DUAL),?,?,?)";
	public static final String TRANSACTIONID_QUERY_SEQUENCE="SELECT transactionId_sequence.CURRVAL FROM DUAL";
	
	
}