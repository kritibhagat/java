package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.bean.*;

import com.capgemini.bank.bean.*;
import com.capgemini.exception.*;
import com.capgemini.exception.*;
import com.capgemini.exception.BankException;

import com.capgemini.bank.bean.DemandDraft;


public interface IDemandDraftDAO {
	public int addDemandDraftDetails(DemandDraft demanddraft) throws BankException;
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException;
	
}
