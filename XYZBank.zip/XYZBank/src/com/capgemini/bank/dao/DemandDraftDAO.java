package com.capgemini.bank.dao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.dao.*;
import com.capgemini.bank.dao.*;
import com.capgemini.bank.ui.*;
import com.capgemini.exception.*;
import com.capgemini.bank.util.*;
import com.capgemini.bank.dao.*;
import com.capgemini.exception.*;
import com.capgemini.exception.BankException;
import com.capgemini.bank.util.DBConnection;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {
	
	Logger logger=Logger.getRootLogger();
	
	public DemandDraftDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public int addDemandDraftDetails(DemandDraft demanddraft) throws BankException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String transactionId=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, demanddraft.getCustomer_name());
			preparedStatement.setString(2, demanddraft.getPhone_number());
			preparedStatement.setString(3, demanddraft.getIn_favor_of());
			
			preparedStatement.setString(4, demanddraft.getDd_amount());
			preparedStatement.setString(5, demanddraft.getDd_description());
			
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSACTIONID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				transactionId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new BankException("Inserting customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return transactionId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new BankException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");

			}
		}
		
		
	}

	

	@Override
	public  DemandDraft getDemandDraftDetails(int transactionId) throws BankException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
	DemandDraft demand=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_CUSTOMER_DETAILS_QUERY);
			preparedStatement.setString(1,transactionId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				demand=new DemandDraft();
				demand.setCustomer_name(resultset.getString(1));
				demand.setPhone_number(resultset.getString(2));
				demand.setIn_favor_of(resultset.getString(3));
				demand.setDd_amount(resultset.getString(4));
				demand.setDd_description(resultset.getString(4));
				
				
				
			}
			
			if( demand != null)
			{
				logger.info("Record Found Successfully");
				return demand;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new BankException("Error in closing db connection");

			}
		}
		
	}
	}