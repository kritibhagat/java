package com.capgemini.bank.test;  

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.exception.BankException;
import com.capgemini.bank.dao.DemandDraftDAO;

import com.capgemini.bank.bean.DemandDraft;


public class DemandDraftDaoTest {

    static DemandDraftDAO dao;
    static DemandDraft demanddraft;

    @BeforeClass
    public static void initialize() {
        dao = new DemandDraftDAO();
        demanddraft = new DemandDraft();
    }

    @Test
    public void testAddDemandDrafttDetails() throws BankException {

        assertNotNull(dao.addDemandDraftDetails(demanddraft));
    }
    
    /************************************
     * Test case for addDemandDraftDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddDemandDraftDetails1() throws BankException {
        assertEquals(1001, dao.addDemandDraftDetails(demanddraft));
    }

    /************************************
     * Test case for addDemandDraftDetails()
     * 
     ************************************/

    @Test
    public void testAddDemandDraftDetails2() throws BankException {
        
    	demanddraft.setCustomer_name("com");
    	demanddraft.setPhone_number("9000342237");
    	demanddraft.setIn_favor_of("Cap");
    	demanddraft.setDd_amount("2000");
    	demanddraft.setDd_description("fav");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addDemandDraftDetails(demanddraft)) > 1000);

    }
}