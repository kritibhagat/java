package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.bean.*;

import com.capgemini.bank.bean.*;
import com.capgemini.exception.*;
import com.capgemini.exception.*;
import com.capgemini.exception.BankException;

import com.capgemini.bank.bean.DemandDraft;


public interface IDemandDraftService {
	public int addDemandDraftDetails(DemandDraft demanddraft) throws BankException;
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException;
	
}
