package com.capgemini.bank.service;

import com.capgemini.exception.*;
import com.capgemini.bank.ui.*;
import com.capgemini.exception.BankException;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.dao.DemandDraftDAO;

import com.capgemini.bank.bean.DemandDraft;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public  class DemandDraftService implements IDemandDraftService {
	
	IDemandDraftDAO demanddraftDao;
	
	public String addDemandDraftDetails(DemandDraft demanddraft) throws BankException {
		
		demanddraftDao= new DemandDraftDAO();
		String transaction_Id_Seq;
		transaction_Id_Seq= demanddraftDao.addDemandDraftDetails(demanddraft);
		return transaction_Id_Seq;
	}
	
	
		public void validateDemandDraft(DemandDraft demand) throws Exception
		{
			List<String> validationErrors = new ArrayList<String>();

			//Validating name
			if(!(isValidCustomer_name(demand.getCustomer_name()))) {
				validationErrors.add("\n customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			if(!(isValidIn_favor_of(demand.getIn_favor_of()))){
                validationErrors.add("\n Should Be In Alphabets and minimum 3 characters long ! \\n");
            }
			//Validating Phone Number
			if(!(isValidPhone_number(demand.getPhone_number()))){
				validationErrors.add("\n Phone Number Should be in 10 digit \n");
			}
			//validating description
			if(!(isValidDd_description(demand.getDd_description()))){
				validationErrors.add("\n description should be in alphabets\n");
			}
			//validating amount
			if(!(isValidDd_amount(demand.getDd_amount()))){
				validationErrors.add("\n should be in number\n");
			}
		
			if(!validationErrors.isEmpty())
				throw new BankException(validationErrors +"");
		}

		public boolean isValidCustomer_name(String name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(name);
			return nameMatcher.matches();
		}
		
		  public boolean isValidIn_favor_of(String in_favor_of){
	            
	            Pattern infavorofPattern=Pattern.compile("^[A-Za-z]{3,}$");
	            Matcher infavorofMatcher=infavorofPattern.matcher(in_favor_of);
	                return infavorofMatcher.matches();
	        }
		
		public boolean isValidPhone_number(String phone_number){
			Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(phone_number);
			return phoneMatcher.matches();
			
		}
		public boolean isValidDd_description(String dd_description){
            
            Pattern dd_descriptionPattern=Pattern.compile("^[A-Za-z]{3,}$");
            Matcher dd_descriptionMatcher=dd_descriptionPattern.matcher(dd_description);
                return dd_descriptionMatcher.matches();
        }
		public boolean isValidDd_amount(String dd_amount){
            
            Pattern dd_amountPattern=Pattern.compile("^([1-9]{2,}$)");
            Matcher dd_amountMatcher=dd_amountPattern.matcher(dd_amount);
                return dd_amountMatcher.matches();
        }
		
		public boolean validateTransactionId(String transactionid) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(transactionid);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}


		
		public DemandDraft getDemandDraftDetails(int transactionId) throws BankException {
			demanddraftDao=new DemandDraftDAO();
			DemandDraft demand=null;
			demand=demanddraftDao.getDemandDraftDetails(transactionId);
			return demand;
		}
}


		
