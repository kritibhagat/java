package com.capgemini.bank.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.ui.*;
import com.capgemini.bank.service.*;
import com.capgemini.exception.*;
import com.capgemini.exception.BankException;
import com.capgemini.bank.service.DemandDraftService;

import com.capgemini.bank.bean.DemandDraft;

import com.capgemini.bank.service.IDemandDraftService;
//import com.capgemini.dao;
import java.lang.NullPointerException;

@SuppressWarnings("unused")
public class Client  {

	static Scanner sc = new Scanner(System.in);
	static IDemandDraftService demanddraftService = null;
	static DemandDraftService demanddraftservice = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		DemandDraft demanddraft = null;

		String transactionId = null;
		int option = 0;

		while (true) {

			// show menu
			
			System.out.println();
			System.out.println();
			System.out.println("   XYZ Banking Application ");
			System.out.println("-----------------------------\n");

			System.out.println("1.Enter Demand Draft Details");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			
			
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (demanddraft  == null) {
						demanddraft   = populateDemandDraft ();
						 System.out.println(demanddraft);
					}

					try {
						demanddraftService = new DemandDraftService();
						transactionId = demanddraftService.addDemandDraftDetails(demanddraft);

						System.out.println("Your DemandDraft request has been successfully registered along with the" +transactionId);
						

					} catch (BankException bankException) {
						logger.error("exception occured", bankException);
						System.out.println("ERROR : "
								+ bankException.getMessage());
					} finally {
						transactionId = null;
						demanddraftService = null;
						demanddraft = null;
					}

					break;
				
				
				case 2:
				{
					demanddraftservice = new DemandDraftService();

					System.out.println("Enter numeric id:");
				transactionId = sc.next();

					while (true) {
						if (demanddraftservice.validateTransactionId(transactionId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric transaction id only, try again");
							transactionId = sc.next();
						}
					}

					demanddraft = getDemandDraftDetails(transactionId);

					if (demanddraft != null) {
						System.out.println("Name of the bank: XYZ");
						System.out.println("DD amount          :"
								+ demanddraft.getDd_amount());
						System.out.println("Commission     :"
								+ demanddraft.commission());
						System.out.println("Total Amount      :"
								+ demanddraft.totalamount());
						System.out.println("Remarks           :"
								+ demanddraft.getDd_description());
						
					} else {
						System.err
								.println("There are no details associated with this id "
										+ transactionId);
					}

					break;

				}

				case 3:

					System.out.print("Exit XYZ Bank ");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}  // end of while
	}

	




	





	private static DemandDraft getDemandDraftDetails(String transactionId) {
		DemandDraft demanddraft = null;
		demanddraftService = new DemandDraftService();

		try {
			demanddraft = demanddraftService.getDemandDraftDetails(transactionId);
		} catch (BankException bankException) {
			logger.error("exception occured ", bankException);
			System.out.println("ERROR : " + bankException.getMessage());
		}

		demanddraftService = null;
		return demanddraft;
	}












	private static Patientbean populatePatientbean() throws Exception {

		
		Patientbean patientbean = new Patientbean();

		System.out.println("\n Patient Details");

		System.out.println("Enter  name: ");
		patientbean.setName(sc.next());
		System.out.println("Enter age: ");
		patientbean.setAge(sc.next());
		System.out.println("Enter phone: ");
		patientbean.setPhoneNumber(sc.next());
		System.out.println("Enter Description: ");
		patientbean.setDescription(sc.next());
		
	
		
        patientServiceImpl = new PatientServiceImpl();


		try {
			patientServiceImpl.validatePatient(patientbean);
			
			System.out.println("after validate patient");
			return patientbean ;
		} catch (PatientsException patientsException) {
			logger.error("exception occured", patientsException);
			System.err.println("Invalid data:");
			System.err.println(patientsException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
