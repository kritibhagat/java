package com.capgemini.exception;

public class BankException extends Exception {
private static final long serialVersionUID = 726264577455921591L;
	public BankException(String message) 
	{
		
		super(message);
	}

}
