public class Client {

	public static void main(String[] args) throws InsufficientOpeningBalanceException {
ICICIBank bank = new ICICIBank();
		
		try {
			System.out.println(bank.createAccount(101, 3000));
		} catch (InsufficientOpeningBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(bank.createAccount(102, 3000));
		
		try
		{
			System.out.println("Balance = "+bank.withdrawAmount(101, 2000));
		}catch(InvalidAccountNumberException i)
		{
			System.out.println("Invalid account number ");
		}
		catch(InsufficientBalanceException ibe){
			System.out.println("insufficient balance");
		}


	}

}
